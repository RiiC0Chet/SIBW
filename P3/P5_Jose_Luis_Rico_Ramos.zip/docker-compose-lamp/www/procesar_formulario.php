<?php 

require_once "/usr/local/lib/php/vendor/autoload.php";

require_once "bd.php";

$loader = new \Twig\Loader\FilesystemLoader('templates');
$twig = new \Twig\Environment($loader);


$mysql = new Mysql();

session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Obtener los datos del formulario
    $nombre = $_POST["nombre"];
    $fechaNacimiento = $_POST["fecha_nacimiento"];
    $fechaMuerte = $_POST["fecha_muerte"];
    $textoVida = $_POST["texto_vida"];
    $textoInteres = $_POST["texto_interes"];
    $enlaceInteres = $_POST["enlace_interes"];

    // Verificar si se ha cargado una imagen
    if (isset($_FILES["imagen"]) ) {
        $errors= array();
        // Obtener información del archivo
        $nombreArchivo = $_FILES["imagen"]["name"];
        $tipoArchivo = $_FILES["imagen"]["type"];
        $rutaTemporal = $_FILES["imagen"]["tmp_name"];
        $tamanioArchivo = $_FILES["imagen"]["size"];
        //$file_ext = strtolower(end(explode('.',$_FILES['imagen']['name'])));
        $file_ext_arr = explode('.', $_FILES['imagen']['name']);
        $file_ext = strtolower(end($file_ext_arr));
        
        $extensions= array("jpeg","jpg","png");
        
        if (in_array($file_ext,$extensions) === false){
          $errors[] = "Extensión no permitida, elige una imagen JPEG o PNG.";
        }
        
        if ($tamanioArchivo > 2097152){
          $errors[] = 'Tamaño del fichero demasiado grande';
        }
        
        if (empty($errors)==true) 
        {
            
            // Ruta de destino para guardar la imagen (modifícala según tu configuración)
            $rutaDestino = "imgs/" . $nombreArchivo;

            // Mover el archivo a la ubicación permanente
            if (move_uploaded_file($rutaTemporal, $rutaDestino)) {
                // Aquí puedes guardar la ruta de la imagen en la base de datos
                // junto con los demás datos del formulario
                // ...

                $imagen = true;
                if(!($_FILES["imagen_2"]["size"] > 0))
                {
                    //echo "nooooo 1";
                    $mysql->registrarCientifico($nombre, $fechaNacimiento, $fechaMuerte,$textoVida,$textoInteres,$enlaceInteres,$rutaDestino,null);
                }
                    
                // Mostrar mensaje de éxito
                //echo "¡El formulario se ha enviado y la imagen se ha guardado correctamente!";
            } else {
                // Mostrar mensaje de error si no se pudo mover la imagen
                //echo "Error al mover la imagen a la ubicación permanente.";
            }
        }
        
    } 

    // Verificar si se ha cargado una imagen
    if (isset($_FILES["imagen_2"]) ) {
        $errors= array();
        // Obtener información del archivo
        $nombreArchivo_2 = $_FILES["imagen_2"]["name"];
        $tipoArchivo_2 = $_FILES["imagen_2"]["type"];
        $rutaTemporal_2 = $_FILES["imagen_2"]["tmp_name"];
        $tamanioArchivo_2 = $_FILES["imagen_2"]["size"];
        //$file_ext = strtolower(end(explode('.',$_FILES['imagen']['name'])));
        $file_ext_arr = explode('.', $_FILES['imagen_2']['name']);
        $file_ext = strtolower(end($file_ext_arr));
        
        $extensions= array("jpeg","jpg","png");
        
        if (in_array($file_ext,$extensions) === false){
          $errors[] = "Extensión no permitida, elige una imagen JPEG o PNG.";
        }
        
        if ($tamanioArchivo_2 > 2097152){
          $errors[] = 'Tamaño del fichero demasiado grande';
        }
        
        if (empty($errors)==true) 
        {
            // Ruta de destino para guardar la imagen (modifícala según tu configuración)
            $rutaDestino_2 = "imgs/" . $nombreArchivo_2;

            // Mover el archivo a la ubicación permanente
            if (move_uploaded_file($rutaTemporal_2, $rutaDestino_2)) {
                // Aquí puedes guardar la ruta de la imagen en la base de datos
                // junto con los demás datos del formulario
                // ...

                if($imagen)
                {   
                    //echo "wwwwwwwwwwwwwwww";
                    $mysql->registrarCientifico($nombre, $fechaNacimiento, $fechaMuerte,$textoVida,$textoInteres,$enlaceInteres,$rutaDestino,$rutaDestino_2);
                }
                    
                // Mostrar mensaje de éxito
                //echo "¡El formulario se ha enviado y la imagen se ha guardado correctamente!";
            } else {
                // Mostrar mensaje de error si no se pudo mover la imagen
                //echo "Error al mover la imagen a la ubicación permanente.";
            }
        }
        
    } 
        
    header("Location: index.php");
    
    exit();
} 



?>