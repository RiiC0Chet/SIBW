<?php 

require_once "/usr/local/lib/php/vendor/autoload.php";

require_once "bd.php";

$loader = new \Twig\Loader\FilesystemLoader('templates');
$twig = new \Twig\Environment($loader);


$mysql = new Mysql();

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $pass = $_POST['contrasena'];
    $email = $_POST['email'];
    $nick = $_POST['nick'];
    if(isset($_POST['super']))
        $super = $_POST['super'];

    $mysql->actualizarUsuario($_SESSION['nickUsuario'],$nick,$pass,$email,$super);
    
    
    header("Location: index.php");
    
    exit();
  }


?>