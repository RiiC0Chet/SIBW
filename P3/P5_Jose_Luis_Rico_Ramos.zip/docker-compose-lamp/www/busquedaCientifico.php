
<?php
require_once "bd.php";

//echo json_encode('eeee');

if(isset($_POST['infoFormulario'])){
    $infoFormulario = $_POST['infoFormulario'];

    $mysql = new Mysql();

    $cientificos = $mysql->obtenerCientificosBusqueda($infoFormulario);

    echo json_encode($cientificos);

}
?>
