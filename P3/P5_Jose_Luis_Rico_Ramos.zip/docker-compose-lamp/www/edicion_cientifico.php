<?php 

require_once "/usr/local/lib/php/vendor/autoload.php";

require_once "bd.php";

$loader = new \Twig\Loader\FilesystemLoader('templates');
$twig = new \Twig\Environment($loader);



$mysql = new Mysql();


if (isset($_POST['eliminar']) && !empty($_POST['eliminar'])) {
    $id_cientifico = $_POST['eliminar'];
    $mysql->eliminarCientifico($id_cientifico);
    

}
if (isset($_POST['Publicar']) && !empty($_POST['Publicar'])) {
    $id_cientifico = $_POST['Publicar'];
    $mysql->publicarCientifico($id_cientifico);
    

}
if (isset($_POST['Ocultar']) && !empty($_POST['Ocultar'])) {
    $id_cientifico = $_POST['Ocultar'];
    $mysql->ocultarCientifico($id_cientifico);
    

}

header("Location: index.php");
exit();
  
?>