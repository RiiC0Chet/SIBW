<?php 

require_once "/usr/local/lib/php/vendor/autoload.php";

require_once "bd.php";

$loader = new \Twig\Loader\FilesystemLoader('templates');
$twig = new \Twig\Environment($loader);

$mysql = new Mysql();

$cientificos = $mysql->obtenerCientificos();

  
$variablesParaTwig = [];
  
session_start();

if (isset($_SESSION['nickUsuario'])) {
  $variablesParaTwig = $mysql->getUser($_SESSION['nickUsuario']);

}
/*
for ($i = 0; $i < count($cientificos); $i++) {
  echo $cientificos[$i]['imagen'] . "<br>";
}
*/
echo $twig->render('index.html', ['cientificos' => $cientificos, 'user' => $variablesParaTwig]);

?>