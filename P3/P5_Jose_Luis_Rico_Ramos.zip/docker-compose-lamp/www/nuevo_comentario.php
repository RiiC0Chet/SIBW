<?php 

require_once "/usr/local/lib/php/vendor/autoload.php";

require_once "bd.php";

$loader = new \Twig\Loader\FilesystemLoader('templates');
$twig = new \Twig\Environment($loader);



$mysql = new Mysql();

if (isset($_POST['comentario_editado']) && !empty($_POST['comentario_editado'])) {
    
    $nuevo_comentario = $_POST['comentario_editado'];
    $id_comentario = $_POST['id_comentario_bd'];
    $id_cientifico = $_POST['id_cientifico'];
    //echo "$nuevo_comentario,$id_comentario";
    $mysql->editarComentario($id_comentario,$nuevo_comentario);
    
    header("Location: http://localhost/cientifico.php?scid=" . $id_cientifico);
    exit();
}
elseif (isset($_POST['eliminar']) && !empty($_POST['eliminar'])) {
    $id_comentario = $_POST['eliminar'];
    $id_cientifico = $_POST['id_cientifico'];

    $mysql->eliminarComentario($id_comentario);

    header("Location: http://localhost/cientifico.php?scid=" . $id_cientifico);
    exit();
}
elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comentario = $_POST['comentario'];
    $nombre_comentario = $_POST['nombre_comentario'];
    $correo = $_POST['correo'];
    $id = $_POST['id_cientifico'];
    
    $mysql->registrarComentario($comentario,$nombre_comentario,$correo,$id);

    header("Location: http://localhost/cientifico.php?scid=" . $id);
    
    exit();
  }

  
?>