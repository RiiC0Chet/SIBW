$(document).ready(function() {
    $('#search').on('keyup', function() {
      var infoFormulario = $(this).val();
      console.log("dddddddddddddddddddddddddddddd");
      $.ajax({
        url: 'busquedaCientifico.php',
        method: 'POST',
        data: {infoFormulario: infoFormulario},
        dataType: 'json',
        success: function(response) {
          console.log("vvvvvvvvvvvvvvv");
          console.log(response);
          var resultsDiv = $('#results');
              resultsDiv.empty(); // Limpiamos el contenido previo del div de resultados
  
              // Iteramos sobre el array de resultados y construimos los elementos <a> correspondientes
              for (var i = 0; i < response.length; i++) {
                var scientist = response[i];

                if(scientist.publicado == 1)
                {
                  var scientistLink = $('<a>').attr('href', 'cientifico.php?scid=' + scientist.id).text(scientist.nombre);
                  resultsDiv.append(scientistLink).append('<br>');
                }
                else
                {
                  if(user_super == 3)
                  {
                    var scientistLink = $('<a>').attr('href', 'cientifico.php?scid=' + scientist.id).text(scientist.nombre);
                    resultsDiv.append(scientistLink).append('<br>');
                  }
                }
                
              }
  
          //$('#results').html(response);
        },
        error: function(error){
          console.log(error);
     }
  
      });
    });
  });
  