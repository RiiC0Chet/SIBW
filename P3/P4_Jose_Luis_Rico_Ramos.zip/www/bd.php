<?php

class Mysql extends mysqli
{
    public $conexion, $mysqli;

    public function __construct()
    {
        $this->conectar();
    }

    public function conectar()
    {
        if (!$this->conexion) {
            // servicio (en docker compose.yml), nombre, contraseña, nombre de base de datos
            $this->mysqli = new mysqli("database", "rico", "rico", "SIBW");

            if ($this->mysqli->connect_errno) {
                echo("Fallo conexion: " . $this->mysqli->connect_errno);
                return false;
            }

            $this->conexion = true;
        }

        return $this->mysqli;
    }

    public function obtenerCientifico($scId)
    {
        // Llamamos a la función conectar para obtener la conexión a la base de datos
        //$mysqli = $this->conectar();

        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }

        $cientifico = array('nombre' => 'xxx', 'nacimiento' => 'yyy', 'muerte' => 'muerte', 'imagen' => 'https://img.freepik.com/vector-gratis/concepto-biotecnologia-plana-cientifico_52683-59401.jpg?w=2000', 'texto' => 'texto_1','textoo' => 'texto_2','enlace' => 'no','id' => 1);

        // sacamos primero el nombre, nacimiento y la muerte
        $stmt = $this->mysqli->prepare("SELECT nombre,nacimiento,muerte FROM cientifico WHERE id = ?");
        $stmt->bind_param("i", $scId);
        $validacion = $stmt->execute();
        if($validacion)
        {
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                $fila = $resultado->fetch_assoc();

                $cientifico = ['nombre' => $fila['nombre'], 'nacimiento' => $fila['nacimiento'], 'muerte' => $fila['muerte']];//, 'imagen' => $fila_['url']];
            }
            else
            {
                return -1;
            }


            // sacamos ahora la url de la imagen
            $stmt_ = $this->mysqli->prepare("SELECT * FROM imagen_c WHERE id_cientifico = ?");
            $stmt_->bind_param("i", $scId);
            $stmt_->execute();
            $resultado_ = $stmt_->get_result();

            if ($resultado_->num_rows > 0) {
                $fila_ = $resultado_->fetch_assoc();
                
                $cientifico['imagen'] = $fila_['url'];
                $cientifico['id'] = $fila_['id_cientifico'];
            }

            // sacamos ahora los textos del cuentifico
            $stmt_ = $this->mysqli->prepare("SELECT * FROM texto_c WHERE id_cientifico = ?");
            $stmt_->bind_param("i", $scId);
            $stmt_->execute();
            $resultado_ = $stmt_->get_result();

            $contador = 0;

            if ($resultado_->num_rows > 0) {

                while($fila = $resultado_->fetch_assoc())
                {
                    // hay que tener en cuenta que hay 2 textos distintos
                    if($contador == 0)
                        $cientifico['texto'] = $fila['texto'];
                    else
                        $cientifico['textoo'] = $fila['texto'];

                    $contador++;
                }

                
            }

            // sacamos ahora los enlaces del cientifico
            $stmt_ = $this->mysqli->prepare("SELECT * FROM enlace_c WHERE id_cientifico = ?");
            $stmt_->bind_param("i", $scId);
            $stmt_->execute();
            $resultado_ = $stmt_->get_result();

            if ($resultado_->num_rows > 0) 
            {
                $fila_ = $resultado_->fetch_assoc();
                $cientifico['enlace'] = $fila_['enlace'];
            }

            $stmt->close();
            $stmt_->close();

            
        }
        //echo $cientifico['imagen'];
          //      echo "<br>";
        return $cientifico;
    }

    public function obtenerPalabrasProhibidas()
    {
        // Llamamos a la función conectar para obtener la conexión a la base de datos
        //$mysqli = $this->conectar();

        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }

        $lista = array();

        $stmt = $this->mysqli->prepare("SELECT * FROM prohibidas");
        //$stmt->bind_param("i", $scId);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) 
        {
            while($fila = $resultado->fetch_assoc())
            {
                array_push($lista,$fila['palabra']);
                //$comentario = array('nombre' => $fila['nombre'], 'fecha' => $fila['fecha'], 'comentario' => $fila['comentario']);
                //array_push($lista,$comentario);
            }
                

            
        }

        $stmt->close();


        return $lista;
    }

    public function obtenerImagenesCientifico($scId)
    {
        // Llamamos a la función conectar para obtener la conexión a la base de datos
        //$mysqli = $this->conectar();

        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }

        $lista = array();

        $stmt = $this->mysqli->prepare("SELECT * FROM imagen_c where id_cientifico = ?");
        $stmt->bind_param("i", $scId);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) 
        {
            while($fila = $resultado->fetch_assoc())
            {
                array_push($lista,$fila['url']);
                //$comentario = array('nombre' => $fila['nombre'], 'fecha' => $fila['fecha'], 'comentario' => $fila['comentario']);
                //array_push($lista,$comentario);
            }
                

            
        }

        $stmt->close();


        return $lista;
    }


    public function obtenerComentarios($scId)
    {
        // Llamamos a la función conectar para obtener la conexión a la base de datos
        //$mysqli = $this->conectar();

        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }

        $lista = array();

        $stmt = $this->mysqli->prepare("SELECT id,nombre,fecha,comentario FROM comentarios WHERE id_cientifico = ?");
        $stmt->bind_param("i", $scId);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) 
        {
            while($fila = $resultado->fetch_assoc())
            {
                $comentario = array('id'  => $fila['id'],'nombre' => $fila['nombre'], 'fecha' => $fila['fecha'], 'comentario' => $fila['comentario']);
                array_push($lista,$comentario);
            }
                

            
        }

        $stmt->close();


        return $lista;
    }


    public function obtenerURLCientifico($scId)
    {
        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }

        

        $stmt_ = $this->mysqli->prepare("SELECT * FROM imagen_c WHERE id_cientifico = ?");
        $stmt_->bind_param("i", $scId);
        $stmt_->execute();
        $resultado_ = $stmt_->get_result();

        if ($resultado_->num_rows > 0) {
            $fila_ = $resultado_->fetch_assoc();

            $url =  $fila_['url'];
        }
        else
        {
            return -1;
        }

        $stmt_->close();

        return $url;
    }

    // obtenemos un array con todos los cientificos
    public function obtenerCientificos()
    {
        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }

        $lista = array();
        $contador = 1;
        
        $stmt = $this->mysqli->prepare("SELECT * FROM cientifico");
        $stmt->execute();
        $resultado = $stmt->get_result();

        $numero_cientificos = $resultado->num_rows;

        while($id = $resultado->fetch_assoc())
        {
            array_push($lista,$this->obtenerCientifico($id['id'])); 
        }
        /*
        while ( $numero_cientificos > $contador)
        {
            if ($this->obtenerCientifico($contador) != -1) 
            {
                array_push($lista,$this->obtenerCientifico($contador));
                $contador++;
            }
        }*/


        $contador = 1;

        foreach ($lista as &$valor) {
            $valor['url'] = $this->obtenerURLCientifico($contador);
            $contador++;
        }

        return $lista;
    }

public function registrarUsuario($nombre, $contrasena, $correo)
{
    if (!$this->mysqli) {
        return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
    }

    // codificamos la contrasena
    $nueva_contrena =  password_hash($contrasena, PASSWORD_DEFAULT);
    $super = 0;
    
    $stmt = $this->mysqli->prepare("INSERT INTO usuarios (nick, email, contrasea, super) VALUES (?, ?, ?,?)");
    $stmt->bind_param("sssi", $nombre, $correo, $nueva_contrena,$super);
    $resultado = $stmt->execute();
    
    $stmt->close();


    // Verificar si la ejecución de la consulta fue exitosa
    if ($resultado) 
        return true;
    else 
        return false;
}

/*
public function registrarComentario($comentario,$nombre_comentario,$correo,$id)
{
    if (!$this->mysqli) {
        return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
    }
    
    $fechaActual = date('d/m/Y'); // Formato: Año-Mes-Día
    $id_bien = intval($id);
    //$fecha_bien =  $fechaActual.toString();
    $stmt = $this->mysqli->prepare("INSERT INTO comentarios (id_cientifico,nombre, correo, fecha, comentario) VALUES (?, ?, ?, ?,?)");
    $stmt->bind_param("issss", $id_bien, $nombre_comentario, $correo,$fechaActual,$comentario);
    $resultado = $stmt->execute();
    
    $stmt->close();


    // Verificar si la ejecución de la consulta fue exitosa
    if ($resultado) 
    {
        echo "fffffffffffffffffffff";
        return true;
    }
        
    else 
        return false;
}
*/

public function registrarComentario($comentario, $nombre_comentario, $correo, $id)
{
    if (!$this->mysqli) {
        return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
    }
    
    $fechaActual = date('Y-m-d H:i:s'); // Formato: Año-Mes-Día Hora:Minuto:Segundo
    $id_bien = intval($id);
    
    $stmt = $this->mysqli->prepare("INSERT INTO comentarios (id_cientifico, nombre, correo, fecha, comentario) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $id_bien, $nombre_comentario, $correo, $fechaActual, $comentario);
    $resultado = $stmt->execute();
    
    $stmt->close();

    // Verificar si la ejecución de la consulta fue exitosa
    if ($resultado) {
        return true;
    } else {
        return false;
    }
}

public function registrarCientifico($nombre, $fechaNacimiento, $fechaMuerte,$textoVida,$textoInteres,$enlaceInteres,$rutaDestino,$rutaDestino_2)
{
    if (!$this->mysqli) {
        return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
    }

    // transformamos los formatos de fechas
    //$nacimiento = date("d/m/Y", strtotime($fechaNacimiento));
    //$muerte = date("d/m/Y", strtotime($fechaMuerte));
    
    // insertamos primero en la tabla cientificoss
    $stmt = $this->mysqli->prepare("INSERT INTO cientifico (nombre, nacimiento, muerte) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nombre, $fechaNacimiento, $fechaMuerte);
    $resultado = $stmt->execute();
    
    $stmt->close();

    // obtener el id de cientifico

    $stmt = $this->mysqli->prepare("SELECT id FROM cientifico WHERE nombre = ?");
    $stmt->bind_param("s", $nombre);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $fila = $resultado->fetch_assoc();

        $id_cientifico = $fila['id'];
    }

    // insertamos el enlace auxiliar
    $stmt = $this->mysqli->prepare("INSERT INTO enlace_c (id_cientifico,enlace) VALUES (?, ?)");
    $stmt->bind_param("is", $id_cientifico, $enlaceInteres);
    $resultado = $stmt->execute();
    
    $stmt->close();

    // insertamos los textos
    $stmt = $this->mysqli->prepare("INSERT INTO texto_c (id_cientifico,texto) VALUES (?, ?)");
    $stmt->bind_param("is", $id_cientifico, $textoVida);
    $resultado = $stmt->execute();
    
    $stmt->close();

    $stmt = $this->mysqli->prepare("INSERT INTO texto_c (id_cientifico,texto) VALUES (?, ?)");
    $stmt->bind_param("is", $id_cientifico, $textoInteres);
    $resultado = $stmt->execute();
    
    $stmt->close();

    // insertamos la imagen
    $stmt = $this->mysqli->prepare("INSERT INTO imagen_c (id_cientifico,url) VALUES (?, ?)");
    $stmt->bind_param("is", $id_cientifico, $rutaDestino);
    $resultado = $stmt->execute();
    
    $stmt->close();

    if(!empty($rutaDestino_2))
    {
        // insertamos la 2º imagen
        $stmt = $this->mysqli->prepare("INSERT INTO imagen_c (id_cientifico,url) VALUES (?, ?)");
        $stmt->bind_param("is", $id_cientifico, $rutaDestino_2);
        $resultado = $stmt->execute();
        
        $stmt->close();
    }
    

    // Verificar si la ejecución de la consulta fue exitosa
    if ($resultado) 
        return true;
    else 
        return false;
}
public function actualizarUsuario($nick_real,$nick,$pass,$email,$super)
{


    if (!$this->mysqli) {
        return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
    }
    if($nick == $nick_real || empty($nick))
    {
        $validacion = true;
    }
    else // si no comprobamos que sea super usuario
    {
        $stmt_ = $this->mysqli->prepare("SELECT super FROM usuarios WHERE nick = ?");
        $stmt_->bind_param("s", $nick_real);
        $stmt_->execute();
        $resultado_ = $stmt_->get_result();

        if ($resultado_->num_rows > 0) 
        {
            $fila = $resultado_->fetch_assoc();
    
            // comprobamos que sea super usuario, que equivale a 3
            if($fila['super'] == 3)
            {
                
                $validacion = true;
            }
            else
            {
                $validacion = false;
            }
        }
            
    }
    if($validacion === true)
    {
        
        // Consulta SQL de actualización con prepared statements
        $sql = "UPDATE usuarios SET ";

        // Array para almacenar los valores a actualizar
        $values = array();

        // Verificar si el campo contraseña no está vacío
        if (!empty($pass)) {
            $sql .= "contrasea = ?, ";

            // codificamos la contrasena
            $nueva_contrena =  password_hash($pass, PASSWORD_DEFAULT);
            $values[] = $nueva_contrena;
        }

        // Verificar si el campo email no está vacío
        if (!empty($email)) {
            $sql .= "email = ?, ";
            $values[] = $email;
        }

        

        // Verificar si se ha modificado al menos un campo
        if (!empty($values)) {
            // Eliminar la coma final y agregar la condición WHERE
            $sql = rtrim($sql, ", ") . " WHERE nick = ?";

            // Agregar el valor del ID del usuario (reemplaza 'id' por tu columna de ID)
            if(empty($nick))
            {
                $nick = $nick_real;
            }
            $values[] = $nick;

            // Preparar y ejecutar la consulta
            $stmt = $this->mysqli->prepare($sql);

            if(!($stmt === false))
            {
                    $stmt->bind_param(str_repeat('s', count($values)), ...$values);
                    $resultado = $stmt->execute();

                    
                    // Cerrar la conexión
                    $stmt->close();

                    if ($resultado) 
                        return true;
                    else 
                    {
                        return false;
                        echo "Error al actualizar los datos: " . $stmt->error;
                    }

                    
            } 
            else 
            {
                return false;
                echo "No se han realizado cambios.";
            }
        }
        elseif(!empty($super))    
        {
            $super_bien = intval($super);
            $stmt = $this->mysqli->prepare("UPDATE usuarios SET super = ? WHERE nick = ?");
            $stmt->bind_param("is", $super_bien,$nick);
            $resultado = $stmt->execute();
        } 
    }
    else 
    {
        return false;
        echo "No se han realizado cambios porque no tienes permisos.";
    }
    

}

  // Devuelve la información de un usuario a partir de su nick 
  public function getUser($nick) {

    // sacamos primero el nombre, nacimiento y la muerte
    $stmt = $this->mysqli->prepare("SELECT * FROM usuarios WHERE nick = ?");
    $stmt->bind_param("s", $nick);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    $user = [];

    // Verificar si la ejecución de la consulta fue exitosa
    if ($fila = $result->fetch_assoc())
    {
        $user['nick'] = $fila['nick'];
        $user['super'] = $fila['super'];
        return $user;   
    }
    else 
        return false;
    
  }

  // Devuelve la información de un usuario a partir de su nick 
  public function checkUser($nick,$pass) {

    // sacamos primero el nombre, nacimiento y la muerte
    $stmt = $this->mysqli->prepare("SELECT nick,contrasea FROM usuarios WHERE nick = ?");
    $stmt->bind_param("s", $nick);
    $stmt->execute();
    $resultado = $stmt->get_result();

    while($nombre = $resultado->fetch_assoc())
    {
        if($nombre['nick'] == $nick && password_verify($pass, $nombre['contrasea'] ))
            return true;
    }
    
    return false;
  }

    public function eliminarComentario($id)
    {
        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }
        
        $id_bien = intval($id);
        $stmt = $this->mysqli->prepare("DELETE FROM comentarios WHERE id = ?");
        $stmt->bind_param("i", $id_bien);
        $resultado = $stmt->execute();
        
        $stmt->close();

        // Verificar si la ejecución de la consulta fue exitosa
        if ($resultado) {
            return true;
        } else {
            return false;
        }
    }


    public function editarComentario($id_comentario,$nuevo_comentario)
    {
        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }
        
        $id_bien = intval($id_comentario);
        $stmt = $this->mysqli->prepare("UPDATE comentarios SET comentario = ? WHERE id = ?");
        $stmt->bind_param("si", $nuevo_comentario,$id_bien);
        $resultado = $stmt->execute();
        
        $stmt->close();

        // Verificar si la ejecución de la consulta fue exitosa
        if ($resultado) {
            return true;
        } else {
            return false;
        }
    }

    
public function eliminarCientifico($id_cientifico)
{
    if (!$this->mysqli) {
        return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
    }

    $id = intval($id_cientifico);

    // insertamos primero en la tabla cientificoss
    $stmt = $this->mysqli->prepare("DELETE FROM cientifico WHERE id = ?");
    $stmt->bind_param("i", $id);
    $resultado = $stmt->execute();
    
    $stmt->close();
    
    $stmt = $this->mysqli->prepare("DELETE FROM enlace_c WHERE id_cientifico = ?");
    $stmt->bind_param("i", $id);
    $resultado = $stmt->execute();
    $stmt->close();

    $stmt = $this->mysqli->prepare("DELETE FROM texto_c WHERE id_cientifico = ?");
    $stmt->bind_param("i", $id);
    $resultado = $stmt->execute();
    $stmt->close();

    $stmt = $this->mysqli->prepare("DELETE FROM imagen_c WHERE id_cientifico = ?");
    $stmt->bind_param("i", $id);
    $resultado = $stmt->execute();
    $stmt->close();


    // Verificar si la ejecución de la consulta fue exitosa
    if ($resultado) 
        return true;
    else 
        return false;
}

   
public function editarCientifico($id,$texto_1,$texto_2)
{
    if (!$this->mysqli) {
        return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
    }

    $id_cientifico = intval($id);

    $stmt = $this->mysqli->prepare("DELETE FROM texto_c WHERE id_cientifico = ?");
    $stmt->bind_param("i", $id_cientifico);
    $resultado = $stmt->execute();
    $stmt->close();

    // insertamos los textos
    $stmt = $this->mysqli->prepare("INSERT INTO texto_c (id_cientifico,texto) VALUES (?, ?)");
    $stmt->bind_param("is", $id_cientifico, $texto_1);
    $resultado = $stmt->execute();
    
    $stmt->close();

    $stmt = $this->mysqli->prepare("INSERT INTO texto_c (id_cientifico,texto) VALUES (?, ?)");
    $stmt->bind_param("is", $id_cientifico, $texto_2);
    $resultado = $stmt->execute();
    
    $stmt->close();

    // Verificar si la ejecución de la consulta fue exitosa
    if ($resultado) 
        return true;
    else 
        return false;
}

}


?>
