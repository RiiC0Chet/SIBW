<?php 

require_once "/usr/local/lib/php/vendor/autoload.php";

require_once "bd.php";

$loader = new \Twig\Loader\FilesystemLoader('templates');
$twig = new \Twig\Environment($loader);



$mysql = new Mysql();


if (isset($_POST['eliminar']) && !empty($_POST['eliminar'])) {
    $id_cientifico = $_POST['eliminar'];
    $mysql->eliminarCientifico($id_cientifico);
    

}
header("Location: index.php");
exit();
  
?>