<?php 

require_once "/usr/local/lib/php/vendor/autoload.php";

require_once "bd.php";

$loader = new \Twig\Loader\FilesystemLoader('templates');
$twig = new \Twig\Environment($loader);


$mysql = new Mysql();


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $texto_1 = $_POST['texto_1'];
    $texto_2 = $_POST['texto_2'];
    $id = $_POST['id_cientifico'];
    $mysql->editarCientifico($id,$texto_1,$texto_2);

    
    header("Location: http://localhost/cientifico.php?scid=" . $id);
    
    exit();
  }


?>