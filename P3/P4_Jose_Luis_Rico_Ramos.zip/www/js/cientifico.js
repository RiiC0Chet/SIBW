const boton = document.getElementById('Boton_comentarios');

// Seccion del grid donde estan  los comentarios
const seccion_comentarios = document.getElementById('zona_c');

const seccion_footer = document.getElementById('zona_f');
const boton_comentarios = document.getElementById('boton_comentarios');

// parrafo donde se introducen los comentarios tras boton
const comentarios = document.getElementById('Parrafo_comentarios');

// Donde se introduce el comentario por teclado
const introductor_texto = document.getElementById('comentario');
const introductor_correo = document.getElementById('correo');
const introductor_nombre  = document.getElementById('nombre_comentario');
var cont_comentario = contador_comentarios;
// creamos una variable de fecha
const fecha = new Date();

// obtenemos las palabras prohibidas
const palabras_p  = document.getElementById('palabras_prohibidas_');
var palabrasProhibidas = JSON.parse(palabras_p.dataset.palabrasPro);

// Obtén una referencia al formulario por su id
//const for_nuevo_comentario = document.getElementById('nuevo_comentario');

// comprobamos si se eta metiendo palabras prohibidas y las quitamos
introductor_texto.addEventListener("input", function(event) {
  var texto = event.target.value; // obtenemos el texto introducido en la caja de comentarios
  palabrasProhibidas.forEach(palabra => {
    const expresionRegular = new RegExp(palabra, "gi");
    texto = texto.replace(expresionRegular, "*".repeat(palabra.length)); // reemplazamos la palabra por asteriscos
  });
  event.target.value = texto; // actualizamos el contenido de la caja de comentarios
});


// funcion con la que vamos a comprobar el correo
function validarCorreoElectronico(correo) {
  // Expresión regular para validar un correo electrónico
  const expresionRegular = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  // Comprobamos si el correo cumple con la expresión regular
  if (expresionRegular.test(correo)) {
    return true;
  } else {
    return false;
  }
}

boton.addEventListener('click',() => 
{
    if (seccion_comentarios.style.display == 'none'){
    	seccion_comentarios.style.display = 'grid';
      comentarios.style.display = 'inline';
        seccion_footer.style.gridRow = 6;        
    }
  else{
    seccion_comentarios.style.display = 'none';
    comentarios.style.display = 'none';
    //Cambiamos la disposicion para dejar el footer en su posicion
    seccion_footer.style.gridRow = 5;      
  }
}
);

//boton_comentarios.addEventListener('click',() => 

function crear_comentario(tipo_user)
{
  // Comrpobamos primero antes que nada, que no esten vacios los campos
  if(introductor_correo.value == '' || introductor_correo.value == '' || introductor_correo.value == '' )
    alert('Tienes que introducir todos los campos para poder añadir el comentario');
  else if (!validarCorreoElectronico(introductor_correo.value))
    alert('¡Correo invalido!');
  else {
    var encabezado= new String();

    encabezado += introductor_nombre.value;
    encabezado += ': '; 

    encabezado += fecha.getDate();
    encabezado += '/';
    encabezado += fecha.getMonth()+1;
    encabezado += '/23';

    encabezado += ' | ';
    
    encabezado += fecha.getHours();
    encabezado += ':';
    encabezado += fecha.getMinutes();

    // le metemos negrita al encabezado con el nombre y las fechas
    //comentarios.innerHTML += '<div class="div_comentario_' +cont_comentario+ '" > <p  id="comentario_' +cont_comentario+ '">'+ encabezado.bold() + '<br>' + introductor_texto.value + '<br>' + '</p>' + '<i class="fas fa-pencil-alt" style="font-size:12px;" onclick="editarComentario("div_comentario_' +cont_comentario+ '","comentario_' +cont_comentario+ '")"></i> <i class="fa-regular fa-trash-can" style="font-size:12px;"></i>' + '</div>';
    
    if(parseInt(tipo_user) > 0)
      comentarios.innerHTML += '<div class="div_comentario_' + cont_comentario + '" id="id_div_comentario_' + cont_comentario + '"> <p>' + encabezado.bold() + '<br> </p> <p id="comentario_' + cont_comentario + '">' + introductor_texto.value + '<br>' + '</p>' + '<i class="fas fa-pencil-alt" style="font-size:12px;" onclick="editarComentario(\'div_comentario_' + cont_comentario + '\', \'comentario_' + cont_comentario + '\')"></i> <i class="fa-regular fa-trash-can" style="font-size:12px;" onclick="eliminarComentario(\'id_div_comentario_' + cont_comentario + '\')"></i>' + '</div>';
    else
      comentarios.innerHTML += '<div class="div_comentario_' + cont_comentario + '" id="id_div_comentario_' + cont_comentario + '"> <p>' + encabezado.bold() + '<br> </p> <p id="comentario_' + cont_comentario + '">' + introductor_texto.value + '<br>' + '</p>' + '</div>';

    cont_comentario++;

    document.getElementById("nuevo_comentario").submit();
  }

  //for_nuevo_comentario.submit();
  
}

function eliminarComentario(div_comentario) 
{
  var div = document.getElementById(div_comentario);
  div.parentNode.removeChild(div);
}

function editarComentario(div_comentario, id_comentario,id_cientifico,id_comentario_bd) {
  // Obtener el div del comentario original
  var comentarioDiv = document.querySelector('.' + div_comentario);

  // Obtener el párrafo del comentario original
  var comentarioOriginal = comentarioDiv.querySelector('#' + id_comentario);

  // Crear el textarea editable con el comentario original
  var textarea = document.createElement('textarea');
  textarea.id = 'comentario-editable';
  textarea.value = comentarioOriginal.innerText;

  // Reemplazar el párrafo original por el textarea
  //comentarioDiv.removeChild(comentarioOriginal);
  //comentarioDiv.appendChild(textarea);
  comentarioDiv.replaceChild(textarea,comentarioOriginal);

  // Crear un botón para guardar los cambios
  var guardarBoton = document.createElement('button');
  guardarBoton.id = 'botonGuardar';
  guardarBoton.textContent = 'Guardar';
  guardarBoton.onclick = function () {
    guardarCambios(comentarioDiv, id_cientifico, id_comentario,id_comentario_bd);
  };

  // Agregar el botón al div de comentarios
  comentarioDiv.appendChild(guardarBoton);
}

function editarCientifico(id_cientifico) {
  // Obtener el div del comentario original
  var comentarioDiv = document.querySelector('.div_texto_1');
  var comentarioDiv_2 = document.querySelector('.div_texto_2');

  // Obtener el párrafo del comentario original
  var comentarioOriginal = comentarioDiv.querySelector('#texto_1');
  var comentarioOriginal_2 = comentarioDiv_2.querySelector('#texto_2');

  // Crear el textarea editable con el comentario original
  var textarea = document.createElement('textarea');
  textarea.style.width = '300px';
  textarea.style.height = '300px';
  textarea.id = 'comentario-editable-1';
  textarea.value = comentarioOriginal.innerText;

  var textarea_2 = document.createElement('textarea');
  textarea_2.style.width = '300px';
  textarea_2.style.height = '300px';
  textarea_2.id = 'comentario-editable-2';
  textarea_2.value = comentarioOriginal_2.innerText;

  // Reemplazar el párrafo original por el textarea
  //comentarioDiv.removeChild(comentarioOriginal);
  //comentarioDiv.appendChild(textarea);
  comentarioDiv.replaceChild(textarea,comentarioOriginal);
  comentarioDiv_2.replaceChild(textarea_2,comentarioOriginal_2);
  // Crear un botón para guardar los cambios
  var guardarBoton = document.createElement('button');
  guardarBoton.id = 'botonGuardar';
  guardarBoton.textContent = 'Guardar';
  guardarBoton.onclick = function () {
    guardarCambiosCientifico(id_cientifico,comentarioDiv,comentarioDiv_2);
  };

  // Agregar el botón al div de comentarios
  comentarioDiv.appendChild(guardarBoton);
}


function guardarCambios(comentarioDiv, id_cientifico, id_comentario,id_comentario_bd) {
  // Obtener el texto editado del textarea
  var comentarioEditado = document.getElementById('comentario-editable').value;
  comentarioEditado += ' COMENTARIO EDITADO!';
  // Crear un nuevo párrafo con el comentario editado
  var nuevoComentario = document.createElement('p');
  nuevoComentario.id = id_comentario;
  nuevoComentario.innerHTML = comentarioEditado;

  // Reemplazar el textarea por el nuevo párrafo
  comentarioDiv.replaceChild(nuevoComentario, document.getElementById('comentario-editable'));

  // Eliminar el botón de guardar
  comentarioDiv.removeChild(document.getElementById('botonGuardar'));

  // Crear un formulario oculto para enviar los datos
  var formulario = document.createElement('form');
  formulario.style.display = 'none';
  formulario.action = 'nuevo_comentario.php'; // Reemplaza "ruta_a_tu_archivo_php.php" por la ruta correcta
  formulario.method = 'POST';

  // Agregar un campo oculto para el ID del comentario
  var inputIdComentario = document.createElement('input');
  inputIdComentario.type = 'hidden';
  inputIdComentario.name = 'id_comentario';
  inputIdComentario.value = id_comentario;
  formulario.appendChild(inputIdComentario);

  // Agregar un campo oculto para el texto del comentario editado
  var inputComentarioEditado = document.createElement('input');
  inputComentarioEditado.type = 'hidden';
  inputComentarioEditado.name = 'comentario_editado';
  inputComentarioEditado.value = comentarioEditado;
  formulario.appendChild(inputComentarioEditado);

  // Agregar un campo oculto para el texto del comentario editado
  var inputNuevoCometarioID = document.createElement('input');
  inputNuevoCometarioID.type = 'hidden';
  inputNuevoCometarioID.name = 'id_comentario_bd';
  inputNuevoCometarioID.value = id_comentario_bd;
  formulario.appendChild(inputNuevoCometarioID);

  // Agregar un campo oculto para la ID del científico
  var inputIdCientifico = document.createElement('input');
  inputIdCientifico.type = 'hidden';
  inputIdCientifico.name = 'id_cientifico';
  inputIdCientifico.value = id_cientifico; // Reemplaza "id_cientifico" con el valor real de la ID del científico
  formulario.appendChild(inputIdCientifico);


  // Agregar el formulario al cuerpo del documento
  document.body.appendChild(formulario);

  // Enviar el formulario
  formulario.submit();
}


function guardarCambiosCientifico(id_cientifico,comentarioDiv,comentarioDiv_2) {
  // Obtener el texto editado del textarea
  var comentarioEditado = document.getElementById('comentario-editable-1').value;
  var comentarioEditado_2 = document.getElementById('comentario-editable-2').value;

  // Crear un nuevo párrafo con el comentario editado
  var nuevoComentario = document.createElement('p');
  nuevoComentario.id = 'texto_1';
  nuevoComentario.innerHTML = comentarioEditado;

  var nuevoComentario_2 = document.createElement('p');
  nuevoComentario_2.id = 'texto_2';
  nuevoComentario_2.innerHTML = comentarioEditado_2;

  // Reemplazar el textarea por el nuevo párrafo
  comentarioDiv.replaceChild(nuevoComentario, document.getElementById('comentario-editable-1'));
  comentarioDiv_2.replaceChild(nuevoComentario_2, document.getElementById('comentario-editable-2'));

  // Eliminar el botón de guardar
  comentarioDiv.removeChild(document.getElementById('botonGuardar'));

  // Crear un formulario oculto para enviar los datos
  var formulario = document.createElement('form');
  formulario.style.display = 'none';
  formulario.action = 'edicion_cientifico_.php'; // Reemplaza "ruta_a_tu_archivo_php.php" por la ruta correcta
  formulario.method = 'POST';

  // Agregar un campo oculto para el ID del comentario
  var inputIdComentario = document.createElement('input');
  inputIdComentario.type = 'hidden';
  inputIdComentario.name = 'texto_1';
  inputIdComentario.value = comentarioEditado;
  formulario.appendChild(inputIdComentario);

  var inputIdComentario_2 = document.createElement('input');
  inputIdComentario_2.type = 'hidden';
  inputIdComentario_2.name = 'texto_2';
  inputIdComentario_2.value = comentarioEditado_2;
  formulario.appendChild(inputIdComentario_2);
  // Agregar un campo oculto para el texto del comentario editado
  var inputComentarioEditado = document.createElement('input');
  inputComentarioEditado.type = 'hidden';
  inputComentarioEditado.name = 'id_cientifico';
  inputComentarioEditado.value = id_cientifico;
  formulario.appendChild(inputComentarioEditado);

  // Agregar el formulario al cuerpo del documento
  document.body.appendChild(formulario);

  // Enviar el formulario
  formulario.submit();
}


function mostrarFormularioEdicion() {
  var nombreUsuario = document.getElementById('login_usuario');
  var formularioEdicion = document.getElementById('actualizacion_usuario');

  nombreUsuario.style.display = 'none';
  formularioEdicion.style.display = 'block';
}
