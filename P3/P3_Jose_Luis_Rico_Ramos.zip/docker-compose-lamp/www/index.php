<?php 

require_once "/usr/local/lib/php/vendor/autoload.php";

require_once "bd.php";

$loader = new \Twig\Loader\FilesystemLoader('templates');
$twig = new \Twig\Environment($loader);

$nombre = 'Marie Curie';
$nacimiento = '1866';
$muerte = '1934';

$mysql = new Mysql();

$cientificos = $mysql->obtenerCientificos();


echo $twig->render('index.html', ['cientificos' => $cientificos]);

// echo $twig->render('index.html', ['nombre' => $nombre,'nacimiento' => $nacimiento, 'muerte' => $muerte]);

?>