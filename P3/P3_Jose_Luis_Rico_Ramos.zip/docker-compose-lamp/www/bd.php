<?php

class Mysql extends mysqli
{
    public $conexion, $mysqli;

    public function __construct()
    {
        $this->conectar();
    }

    public function conectar()
    {
        if (!$this->conexion) {
            // servicio (en docker compose.yml), nombre, contraseña, nombre de base de datos
            $this->mysqli = new mysqli("database", "rico", "rico", "SIBW");

            if ($this->mysqli->connect_errno) {
                echo("Fallo conexion: " . $this->mysqli->connect_errno);
                return false;
            }

            $this->conexion = true;
        }

        return $this->mysqli;
    }

    public function obtenerCientifico($scId)
    {
        // Llamamos a la función conectar para obtener la conexión a la base de datos
        //$mysqli = $this->conectar();

        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }

        $cientifico = array('nombre' => 'xxx', 'nacimiento' => 'yyy', 'muerte' => 'muerte', 'imagen' => 'https://img.freepik.com/vector-gratis/concepto-biotecnologia-plana-cientifico_52683-59401.jpg?w=2000', 'texto' => 'texto_1','textoo' => 'texto_2','enlace' => 'no','id' => 1);

        // sacamos primero el nombre, nacimiento y la muerte
        $stmt = $this->mysqli->prepare("SELECT nombre,nacimiento,muerte FROM cientifico WHERE id = ?");
        $stmt->bind_param("i", $scId);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            $fila = $resultado->fetch_assoc();

            $cientifico = ['nombre' => $fila['nombre'], 'nacimiento' => $fila['nacimiento'], 'muerte' => $fila['muerte']];//, 'imagen' => $fila_['url']];
        }
        else
        {
            return -1;
        }


        // sacamos ahora la url de la imagen
        $stmt_ = $this->mysqli->prepare("SELECT * FROM imagen_c WHERE id_cientifico = ?");
        $stmt_->bind_param("i", $scId);
        $stmt_->execute();
        $resultado_ = $stmt_->get_result();

        if ($resultado_->num_rows > 0) {
            $fila_ = $resultado_->fetch_assoc();

            $cientifico['imagen'] = $fila_['url'];
            $cientifico['id'] = $fila_['id_cientifico'];
        }

        // sacamos ahora los textos del cuentifico
        $stmt_ = $this->mysqli->prepare("SELECT * FROM texto_c WHERE id_cientifico = ?");
        $stmt_->bind_param("i", $scId);
        $stmt_->execute();
        $resultado_ = $stmt_->get_result();

        $contador = 0;

        if ($resultado_->num_rows > 0) {

            while($fila = $resultado_->fetch_assoc())
            {
                // hay que tener en cuenta que hay 2 textos distintos
                if($contador == 0)
                    $cientifico['texto'] = $fila['texto'];
                else
                    $cientifico['textoo'] = $fila['texto'];

                $contador++;
            }

            
        }

        // sacamos ahora los enlaces del cientifico
        $stmt_ = $this->mysqli->prepare("SELECT * FROM enlace_c WHERE id_cientifico = ?");
        $stmt_->bind_param("i", $scId);
        $stmt_->execute();
        $resultado_ = $stmt_->get_result();

        if ($resultado_->num_rows > 0) 
        {
            $fila_ = $resultado_->fetch_assoc();
            $cientifico['enlace'] = $fila_['enlace'];
        }

        $stmt->close();
        $stmt_->close();

        return $cientifico;
    }

    public function obtenerPalabrasProhibidas()
    {
        // Llamamos a la función conectar para obtener la conexión a la base de datos
        //$mysqli = $this->conectar();

        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }

        $lista = array();

        $stmt = $this->mysqli->prepare("SELECT * FROM prohibidas");
        //$stmt->bind_param("i", $scId);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) 
        {
            while($fila = $resultado->fetch_assoc())
            {
                array_push($lista,$fila['palabra']);
                //$comentario = array('nombre' => $fila['nombre'], 'fecha' => $fila['fecha'], 'comentario' => $fila['comentario']);
                //array_push($lista,$comentario);
            }
                

            
        }

        $stmt->close();


        return $lista;
    }

    public function obtenerImagenesCientifico($scId)
    {
        // Llamamos a la función conectar para obtener la conexión a la base de datos
        //$mysqli = $this->conectar();

        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }

        $lista = array();

        $stmt = $this->mysqli->prepare("SELECT * FROM imagen_c where id_cientifico = ?");
        $stmt->bind_param("i", $scId);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) 
        {
            while($fila = $resultado->fetch_assoc())
            {
                array_push($lista,$fila['url']);
                //$comentario = array('nombre' => $fila['nombre'], 'fecha' => $fila['fecha'], 'comentario' => $fila['comentario']);
                //array_push($lista,$comentario);
            }
                

            
        }

        $stmt->close();


        return $lista;
    }


    public function obtenerComentarios($scId)
    {
        // Llamamos a la función conectar para obtener la conexión a la base de datos
        //$mysqli = $this->conectar();

        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }

        $lista = array();

        $stmt = $this->mysqli->prepare("SELECT nombre,fecha,comentario FROM comentarios WHERE id_cientifico = ?");
        $stmt->bind_param("i", $scId);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) 
        {
            while($fila = $resultado->fetch_assoc())
            {
                $comentario = array('nombre' => $fila['nombre'], 'fecha' => $fila['fecha'], 'comentario' => $fila['comentario']);
                array_push($lista,$comentario);
            }
                

            
        }

        $stmt->close();


        return $lista;
    }


    public function obtenerURLCientifico($scId)
    {
        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }

        

        $stmt_ = $this->mysqli->prepare("SELECT * FROM imagen_c WHERE id_cientifico = ?");
        $stmt_->bind_param("i", $scId);
        $stmt_->execute();
        $resultado_ = $stmt_->get_result();

        if ($resultado_->num_rows > 0) {
            $fila_ = $resultado_->fetch_assoc();

            $url =  $fila_['url'];
        }
        else
        {
            return -1;
        }

        $stmt_->close();

        return $url;
    }

    // obtenemos un array con todos los cientificos
    public function obtenerCientificos()
    {
        if (!$this->mysqli) {
            return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
        }

        $lista = array();
        $contador = 1;

        while ($this->obtenerCientifico($contador) != -1) 
        {
            array_push($lista,$this->obtenerCientifico($contador));
            $contador++;
        }

        $contador = 1;

        foreach ($lista as &$valor) {
            $valor['url'] = $this->obtenerURLCientifico($contador);
            $contador++;
        }

        return $lista;
    }

}


    /*
    class Mysql extends mysqli
    {
        public  $conexion, $mysqli;

        public function __construct()
        {
            $this->conectar();
        }

        public function conectar()
        {
            
            if(! $this->$conexion)
            {
                // servicio (en docker compose.yml), nombre, contraseña, nombre de base de datos
                $this->$mysqli = new mysqli("database", "rico", "rico", "SIBW");

                if( $this->$mysqli->connect_errno)
                {
                    echo("Fallo conexion: ".  $this->$mysqli->connect_errno);
                    return false;
                }
                
                $this->$conexion = true;
            }
            
            return  $this->$mysqli;
        }

        public function obtenerCientifico($scId)
        {
            // Llamamos a la función conectar para obtener la conexión a la base de datos
            $this->$mysqli = conectar();

            if (! $this->$mysqli) {
                return null; // O cualquier otro valor o mensaje que indique que ha habido un error en la conexión
            }

            $cientifico = array('nombre' => 'xxx', 'nacimiento' => 'yyy', 'muerte' => 'muerte', 'imagen' => 'https://img.freepik.com/vector-gratis/concepto-biotecnologia-plana-cientifico_52683-59401.jpg?w=2000');

            $stmt =  $this->$mysqli->prepare("SELECT nombre,nacimiento,muerte FROM cientifico WHERE id = ? ");
            

            $stmt->bind_param("i", $scId);
            $stmt->execute();
            $resultado = $stmt->get_result();
            
            
    
            if($resultado->num_rows > 0 )
            {
                $fila = $resultado->fetch_assoc();

                $cientifico = ['nombre' => $fila['nombre'], 'nacimiento' => $fila['nacimiento'], 'muerte' => $fila['muerte']];//, 'imagen' => $fila_['url']];
            }

            $stmt_ =  $this->$mysqli->prepare("SELECT * FROM imagen_c WHERE id_cientifico = ?" );
            $stmt_->bind_param("i", $scId);
            $stmt_->execute();
            $resultado_ = $stmt_->get_result();

            if($resultado_->num_rows > 0 )
            {
                $fila_ = $resultado_->fetch_assoc();

                $cientifico['imagen'] = $fila_['url'];
            }


            $stmt->close();
            $stmt_->close();

            return $cientifico;
            
        }

    }
    */

    /*
    function conectar()
    {
        global $conexion,$mysqli;

        if(!$conexion)
        {
            // servicio (en docker compose.yml), nombre, contraseña, nombre de base de datos
            $mysqli = new mysqli("database", "rico", "rico", "SIBW");

            if($mysqli->connect_errno)
            {
                echo("Fallo conexion: ". $mysqli->connect_errno);
            }
        }
    }

    function obtenerCientifico($scId)
    {

        // Estamos creando una conexion por consulta, ESO HAY QUE CAMBIARLO, MIRAR COMO
        // Mirar lo de las sentencias preparadas
        // https://websitebeaver.com/prepared-statements-in-php-mysqli-to-prevent-sql-injection
        // si te aburres mirar la forma de pasar los paramtros con / en vez de tal ual

        conectar();

        $cientifico = array('nombre' => 'xxx', 'nacimiento' => 'yyy', 'muerte' => 'muerte');

        $resultado = $mysqli->query("SELECT nombre,nacimiento,muerte FROM cientifico WHERE id = " . $scId);

        if($resultado->num_rows > 0)
        {
            $fila = $resultado->fetch_assoc();

            $cientifico = ['nombre' => $fila['nombre'], 'nacimiento' => $fila['nacimiento'], 'muerte' => $fila['muerte']];
        }

        return $cientifico;
    }
    */

?>
