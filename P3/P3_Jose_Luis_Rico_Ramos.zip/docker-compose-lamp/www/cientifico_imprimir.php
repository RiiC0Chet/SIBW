<?php 

require_once "/usr/local/lib/php/vendor/autoload.php";

require_once "bd.php";

$loader = new \Twig\Loader\FilesystemLoader('templates');
$twig = new \Twig\Environment($loader);

if(isset($_GET['scid']))
{
    $scId = $_GET['scid'];
}
else
{
    $scId = -1;
}

// Lo   que le pasamos por la URL, si esta ssignada le asignamos lo que pasen, si no le asignamos -1
//$scId = (isset($_GET['scid'])) ? $_GET['scid'] : -1 ;

$mysql = new Mysql();

$cientifico = $mysql->obtenerCientifico($scId);
$imagenes = $mysql->obtenerImagenesCientifico($scId);

echo $twig->render('cientifico_imprimir.html', ['cientifico' => $cientifico, 'imagenes' => $imagenes]);

//echo $twig->render('cientifico_imprimir.html', ['nombre' => $nombre,'nacimiento' => $nacimiento, 'muerte' => $muerte]);

?>